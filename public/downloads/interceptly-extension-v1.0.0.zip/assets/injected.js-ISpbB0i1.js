(function(){(()=>{console.log("[Interceptly] Main world script initialized");const g=window.fetch,E=window.XMLHttpRequest;let R=[],w="";window.addEventListener("__INTERCEPTLY_RULES_UPDATE__",t=>{console.log("[Interceptly] Rules updated:",t.detail.rules),R=t.detail.rules||[],w=t.detail.logoUrl||""});function x(){console.log("[Interceptly] Requesting rules..."),window.dispatchEvent(new CustomEvent("__INTERCEPTLY_MAIN_READY__"))}x(),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",x):x();function d(t){try{return new URL(t.toString(),window.location.href).href}catch{return t.toString()}}function v(t,a="GET"){const s=d(t),o=a.toUpperCase();for(const e of R){if(!e.enabled||e.methods&&e.methods.length>0&&!e.methods.map(c=>c.toUpperCase()).includes(o))continue;if(e.matchType==="equals"){if(s===e.urlPattern)return{...e};continue}let r=e.urlPattern.replace(/[.+^${}()|[\]\\]/g,"\\$&").replace(/\*/g,"(.*)");r.includes("\\?")?r+="$":r+="(\\?.*)?$";const p=new RegExp("^"+r),n=s.match(p);if(n){console.log(`[Interceptly] Matched! ${s} matches ${e.urlPattern}`);const i={...e};if(e.type==="redirect"&&i.redirectUrl){let c=i.redirectUrl;for(let l=1;l<n.length;l++)c=c.replace(`$${l}`,n[l]||"");i.redirectUrl=c}return i}}return null}function y(t,a){if(!document.body)return;const s="interceptly-snackbar-container";let o=document.getElementById(s);if(!o){o=document.createElement("div"),o.id=s,o.style.cssText=`
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 2147483647;
        display: flex;
        flex-direction: column;
        gap: 10px;
        pointer-events: none;
      `,document.body.appendChild(o);const l="interceptly-styles";if(!document.getElementById(l)){const f=document.createElement("style");f.id=l,f.textContent=`
          @keyframes interceptly-slide-in {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
          .interceptly-snackbar {
            background: #0f172a !important;
            color: #f1f5f9 !important;
            padding: 10px 14px !important;
            border-radius: 12px !important;
            font-family: inherit !important;
            font-size: 13px !important;
            box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.5) !important;
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
            min-width: 320px !important;
            max-width: 450px !important;
            border: 1px solid #1e293b !important;
            pointer-events: auto !important;
            animation: interceptly-slide-in 0.3s cubic-bezier(0, 0, 0.2, 1) !important;
            transition: all 0.3s ease !important;
            backdrop-filter: blur(8px) !important;
          }
        `,document.head.appendChild(f)}}const e=document.createElement("div");e.className="interceptly-snackbar";const r=a.length>40?a.substring(0,37)+"...":a;let p="Mocked",n=`with status ${t.statusCode||200}`,i="#8b5cf6";t.type==="block"?(p="Blocked",n="Request prevented",i="#ef4444"):t.type==="redirect"&&(p="Redirected",n=`to ${t.redirectUrl.substring(0,20)}...`,i="#10b981"),e.innerHTML=`
      <div style="width: 32px; height: 32px; flex-shrink: 0; background: #1e293b; border-radius: 8px; display: flex; items-center; justify-content: center; overflow: hidden; border: 1px solid #334155;">
        ${w?`<img src="${w}" style="width: 100%; height: 100%; object-fit: cover;" />`:'<div style="color: white; font-weight: bold; font-size: 10px;">i</div>'}
      </div>
      <div style="flex: 1; overflow: hidden; padding: 2px 0;">
        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px;">
          <span style="color: ${i}; font-weight: bold; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em;">${p}</span>
          <span style="color: #64748b; font-size: 10px;">•</span>
          <span style="color: #94a3b8; font-size: 11px; font-family: monospace;">${n}</span>
        </div>
        <div style="font-weight: 500; font-size: 12px; color: #f1f5f9; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${r}</div>
      </div>
      <button style="background: none; border: none; color: #475569; cursor: pointer; padding: 4px; font-size: 18px; line-height: 1; transition: color 0.2s;" onmouseover="this.style.color='#f1f5f9'" onmouseout="this.style.color='#475569'">&times;</button>
    `;const c=()=>{e.style.opacity="0",e.style.transform="translateY(-10px)",setTimeout(()=>e.remove(),300)};e.querySelector("button").onclick=c,o.appendChild(e),setTimeout(c,4e3)}function u(t){window.dispatchEvent(new CustomEvent("__INTERCEPTLY_NETWORK_ACTIVITY__",{detail:{id:Math.random().toString(36).substring(2,9),timestamp:Date.now(),...t}}))}window.fetch=async function(...t){const a=t[0],s=typeof a=="string"?a:a instanceof Request?a.url:a.toString(),o=t[1]&&t[1].method||"GET",e=v(s,o);if(e){if(e.type==="block")return console.log(`[Interceptly] Blocking fetch: ${s}`),y(e,s),Promise.reject(new Error("Request blocked by Interceptly"));if(e.type==="redirect"){console.log(`[Interceptly] Redirecting fetch: ${s} -> ${e.redirectUrl}`),y(e,s);const n=[...t];return typeof n[0]=="string"||n[0]instanceof URL?n[0]=e.redirectUrl:n[0]instanceof Request&&(n[0]=new Request(e.redirectUrl,n[0])),g.apply(this,n)}const r=e.statusCode||200;console.log(`[Interceptly] Mocking fetch: ${s} -> ${r}`),y(e,s),e.executeRealRequest&&g.apply(this,t).catch(n=>{console.error("[Interceptly] Real fetch failed (pass-through):",n)});const p={url:d(s),method:o,status:r,responseBody:e.responseBody,isMocked:!0};return u(p),new Response(e.responseBody,{status:r,headers:{"Content-Type":e.contentType||"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"*","Access-Control-Allow-Methods":"*"}})}try{const r=await g.apply(this,t);return r.clone().text().then(n=>{u({url:d(s),method:o,status:r.status,responseBody:n,isMocked:!1})}).catch(()=>{u({url:d(s),method:o,status:r.status,responseBody:"[Unable to parse body]",isMocked:!1})}),r}catch(r){throw u({url:d(s),method:o,status:0,responseBody:r.message,isMocked:!1,error:!0}),r}},window.XMLHttpRequest=function(){const t=new E,a=t.open,s=t.send;let o=null,e="",r="GET";t.open=function(n,i,...c){return r=n,e=i.toString(),o=v(e,r),o&&o.type==="redirect"?(console.log(`[Interceptly] Redirecting XHR: ${e} -> ${o.redirectUrl}`),y(o,e),a.apply(this,[n,o.redirectUrl,...c])):a.apply(this,[n,i,...c])},t.send=function(n){if(o){if(o.type==="block"){console.log(`[Interceptly] Blocking XHR: ${e}`),y(o,e),setTimeout(()=>{this.dispatchEvent(new Event("error")),this.onerror&&this.onerror()},0);return}if(o.type==="redirect")return s.apply(this,[n]);const l=o.statusCode||200;y(o,e);const f={url:d(e),method:r,status:l,responseBody:o.responseBody,isMocked:!0};if(u(f),o.executeRealRequest){const h=t.onreadystatechange,m=t.onload;return t.onreadystatechange=function(b){t.readyState===4&&p(t,o,e),h&&h.apply(this,[b])},t.onload=function(b){p(t,o,e),m&&m.apply(this,[b])},s.apply(this,[n])}console.log(`[Interceptly] Mocking XHR: ${e} -> ${l}`),p(this,o,e),setTimeout(()=>{this.dispatchEvent(new Event("readystatechange")),this.dispatchEvent(new Event("load")),this.dispatchEvent(new Event("loadend")),this.onreadystatechange&&this.onreadystatechange(),this.onload&&this.onload()},0);return}const i=t.onload;t.onload=function(l){u({url:d(e),method:r,status:t.status,responseBody:t.responseText,isMocked:!1}),i&&i.apply(this,[l])};const c=t.onerror;return t.onerror=function(l){u({url:d(e),method:r,status:0,responseBody:"[Network Error]",isMocked:!1,error:!0}),c&&c.apply(this,[l])},s.apply(this,[n])};function p(n,i,c){const l=i.statusCode||200,f={status:l,statusText:l===404?"Not Found":"OK",responseText:i.responseBody,response:i.responseBody,readyState:4,responseURL:d(c)};Object.entries(f).forEach(([h,m])=>{Object.defineProperty(n,h,{get:()=>m,configurable:!0})}),n.getResponseHeader=function(h){return h.toLowerCase()==="content-type"?i.contentType||"application/json":null},n.getAllResponseHeaders=function(){return`content-type: ${i.contentType||"application/json"}\r
access-control-allow-origin: *\r
`}}return t}})();
})()