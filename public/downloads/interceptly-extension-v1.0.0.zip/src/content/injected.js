// This script runs in the main page world
(() => {
  console.log("[Interceptly] Main world script initialized");

  const originalFetch = window.fetch;
  const originalXHR = window.XMLHttpRequest;

  let mockRules = [];
  let logoUrl = "";

  // Listen for rules from the content script
  window.addEventListener("__INTERCEPTLY_RULES_UPDATE__", (event) => {
    console.log("[Interceptly] Rules updated:", event.detail.rules);
    mockRules = event.detail.rules || [];
    logoUrl = event.detail.logoUrl || "";
  });

  // Tell the content script we are ready to receive rules
  function requestRules() {
    console.log("[Interceptly] Requesting rules...");
    window.dispatchEvent(new CustomEvent("__INTERCEPTLY_MAIN_READY__"));
  }

  // Request rules initially
  requestRules();
  // Request again when DOM is loaded just in case
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", requestRules);
  } else {
    requestRules();
  }

  function normalizeUrl(url) {
    try {
      return new URL(url.toString(), window.location.href).href;
    } catch (_e) {
      return url.toString();
    }
  }

  function getMatchingRule(url, method = "GET") {
    const normalizedUrl = normalizeUrl(url);
    const upperMethod = method.toUpperCase();

    for (const rule of mockRules) {
      if (!rule.enabled) continue;

      // Match HTTP Method if specified
      if (rule.methods && rule.methods.length > 0) {
        const supportedMethods = rule.methods.map((m) => m.toUpperCase());
        if (!supportedMethods.includes(upperMethod)) {
          continue;
        }
      }

      if (rule.matchType === "equals") {
        if (normalizedUrl === rule.urlPattern) {
          return { ...rule };
        }
        continue;
      }

      // Default to "contains" (supporting wildcards)
      // Escape special regex characters except for *
      let pattern = rule.urlPattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, "(.*)");

      // Allow for optional trailing slash and query parameters if not specified in pattern
      if (!pattern.includes("\\?")) {
        pattern += "(\\?.*)?$";
      } else {
        pattern += "$";
      }

      const regex = new RegExp("^" + pattern);
      const match = normalizedUrl.match(regex);

      if (match) {
        console.log(`[Interceptly] Matched! ${normalizedUrl} matches ${rule.urlPattern}`);
        const clonedRule = { ...rule };

        // Handle capture groups for redirects
        if (rule.type === "redirect" && clonedRule.redirectUrl) {
          let redirected = clonedRule.redirectUrl;
          for (let i = 1; i < match.length; i++) {
            redirected = redirected.replace(`$${i}`, match[i] || "");
          }
          clonedRule.redirectUrl = redirected;
        }

        return clonedRule;
      }
    }
    return null;
  }

  function requestSnackbar(rule, url) {
    try {
      window.dispatchEvent(
        new CustomEvent("__INTERCEPTLY_SHOW_SNACKBAR__", {
          detail: { rule, url, logoUrl },
        }),
      );
    } catch (e) {
      console.error("[Interceptly] Failed to request snackbar:", e);
    }
  }

  function reportNetworkActivity(data) {
    window.dispatchEvent(
      new CustomEvent("__INTERCEPTLY_NETWORK_ACTIVITY__", {
        detail: {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: Date.now(),
          ...data,
        },
      }),
    );
  }

  // Override fetch
  window.fetch = async function (...args) {
    const request = args[0];
    const url =
      typeof request === "string"
        ? request
        : request instanceof Request
          ? request.url
          : request.toString();
    const method = (args[1] && args[1].method) || "GET";
    const rule = getMatchingRule(url, method);

    if (rule) {
      if (rule.type === "block") {
        console.log(`[Interceptly] Blocking fetch: ${url}`);
        requestSnackbar(rule, url);
        return Promise.reject(new Error("Request blocked by Interceptly"));
      }

      if (rule.type === "redirect") {
        console.log(`[Interceptly] Redirecting fetch: ${url} -> ${rule.redirectUrl}`);
        requestSnackbar(rule, url);
        const redirectArgs = [...args];
        if (typeof redirectArgs[0] === "string" || redirectArgs[0] instanceof URL) {
          redirectArgs[0] = rule.redirectUrl;
        } else if (redirectArgs[0] instanceof Request) {
          redirectArgs[0] = new Request(rule.redirectUrl, redirectArgs[0]);
        }
        return originalFetch.apply(this, redirectArgs);
      }

      const status = rule.statusCode || 200;
      console.log(`[Interceptly] Mocking fetch: ${url} -> ${status}`);
      requestSnackbar(rule, url);

      // If pass-through is enabled, execute the real request but don't use it
      if (rule.executeRealRequest) {
        originalFetch.apply(this, args).catch((err) => {
          console.error("[Interceptly] Real fetch failed (pass-through):", err);
        });
      }

      const mockResponse = {
        url: normalizeUrl(url),
        method,
        status,
        responseBody: rule.responseBody,
        isMocked: true,
      };
      reportNetworkActivity(mockResponse);

      return new Response(rule.responseBody, {
        status: status,
        headers: {
          "Content-Type": rule.contentType || "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "*",
          "Access-Control-Allow-Methods": "*",
        },
      });
    }

    try {
      const response = await originalFetch.apply(this, args);
      const clonedResponse = response.clone();

      clonedResponse
        .text()
        .then((body) => {
          reportNetworkActivity({
            url: normalizeUrl(url),
            method,
            status: response.status,
            responseBody: body,
            isMocked: false,
          });
        })
        .catch(() => {
          reportNetworkActivity({
            url: normalizeUrl(url),
            method,
            status: response.status,
            responseBody: "[Unable to parse body]",
            isMocked: false,
          });
        });

      return response;
    } catch (err) {
      reportNetworkActivity({
        url: normalizeUrl(url),
        method,
        status: 0,
        responseBody: err.message,
        isMocked: false,
        error: true,
      });
      throw err;
    }
  };

  // Override XHR
  window.XMLHttpRequest = function () {
    const xhr = new originalXHR();
    const originalOpen = xhr.open;
    const originalSend = xhr.send;
    let mockRule = null;
    let requestUrl = "";
    let requestMethod = "GET";

    xhr.open = function (method, url, ...rest) {
      requestMethod = method;
      requestUrl = url.toString();
      mockRule = getMatchingRule(requestUrl, requestMethod);

      if (mockRule && mockRule.type === "redirect") {
        console.log(`[Interceptly] Redirecting XHR: ${requestUrl} -> ${mockRule.redirectUrl}`);
        requestSnackbar(mockRule, requestUrl);
        return originalOpen.apply(this, [method, mockRule.redirectUrl, ...rest]);
      }

      return originalOpen.apply(this, [method, url, ...rest]);
    };

    xhr.send = function (body) {
      if (mockRule) {
        if (mockRule.type === "block") {
          console.log(`[Interceptly] Blocking XHR: ${requestUrl}`);
          requestSnackbar(mockRule, requestUrl);
          // Trigger error after a small delay
          setTimeout(() => {
            this.dispatchEvent(new Event("error"));
            if (this.onerror) this.onerror();
          }, 0);
          return;
        }

        if (mockRule.type === "redirect") {
          // Already handled in open()
          return originalSend.apply(this, [body]);
        }

        const status = mockRule.statusCode || 200;
        requestSnackbar(mockRule, requestUrl);

        const mockActivity = {
          url: normalizeUrl(requestUrl),
          method: requestMethod,
          status,
          responseBody: mockRule.responseBody,
          isMocked: true,
        };
        reportNetworkActivity(mockActivity);

        // If pass-through is enabled, we still send the real request
        if (mockRule.executeRealRequest) {
          // Store original handlers
          const originalOnReadyStateChange = xhr.onreadystatechange;
          const originalOnLoad = xhr.onload;

          // Override them to apply mock data after completion
          xhr.onreadystatechange = function (event) {
            if (xhr.readyState === 4) {
              applyMockProps(xhr, mockRule, requestUrl);
            }
            if (originalOnReadyStateChange) {
              originalOnReadyStateChange.apply(this, [event]);
            }
          };

          xhr.onload = function (event) {
            applyMockProps(xhr, mockRule, requestUrl);
            if (originalOnLoad) {
              originalOnLoad.apply(this, [event]);
            }
          };

          return originalSend.apply(this, [body]);
        }

        console.log(`[Interceptly] Mocking XHR: ${requestUrl} -> ${status}`);

        // Use defineProperty to bypass read-only restrictions
        applyMockProps(this, mockRule, requestUrl);

        // Trigger events
        setTimeout(() => {
          this.dispatchEvent(new Event("readystatechange"));
          this.dispatchEvent(new Event("load"));
          this.dispatchEvent(new Event("loadend"));
          if (this.onreadystatechange) this.onreadystatechange();
          if (this.onload) this.onload();
        }, 0);
        return;
      }

      // Capture real XHR
      const originalOnLoad = xhr.onload;
      xhr.onload = function (event) {
        reportNetworkActivity({
          url: normalizeUrl(requestUrl),
          method: requestMethod,
          status: xhr.status,
          responseBody: xhr.responseText,
          isMocked: false,
        });
        if (originalOnLoad) {
          originalOnLoad.apply(this, [event]);
        }
      };

      const originalOnError = xhr.onerror;
      xhr.onerror = function (event) {
        reportNetworkActivity({
          url: normalizeUrl(requestUrl),
          method: requestMethod,
          status: 0,
          responseBody: "[Network Error]",
          isMocked: false,
          error: true,
        });
        if (originalOnError) {
          originalOnError.apply(this, [event]);
        }
      };

      return originalSend.apply(this, [body]);
    };

    function applyMockProps(xhrInstance, rule, url) {
      const status = rule.statusCode || 200;
      const props = {
        status: status,
        statusText: status === 404 ? "Not Found" : "OK",
        responseText: rule.responseBody,
        response: rule.responseBody,
        readyState: 4,
        responseURL: normalizeUrl(url),
      };

      Object.entries(props).forEach(([key, value]) => {
        Object.defineProperty(xhrInstance, key, {
          get: () => value,
          configurable: true,
        });
      });

      // Mock response headers
      xhrInstance.getResponseHeader = function (header) {
        if (header.toLowerCase() === "content-type") return rule.contentType || "application/json";
        return null;
      };

      xhrInstance.getAllResponseHeaders = function () {
        return `content-type: ${
          rule.contentType || "application/json"
        }\r\naccess-control-allow-origin: *\r\n`;
      };
    }

    return xhr;
  };
})();
